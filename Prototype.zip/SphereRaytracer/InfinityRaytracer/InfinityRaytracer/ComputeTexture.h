#pragma once

#include "stdafx.h"
#include "ComputeBuffer.h"

class ComputeTexture
{
public:	
	
	explicit ComputeTexture();
	~ComputeTexture();

	ID3D11Texture2D*			GetResource()
	{ return _Resource; }
	ID3D11ShaderResourceView*	GetResourceView()
	{ return _ResourceView; }
	ID3D11UnorderedAccessView*	GetUnorderedAccessView()
	{ return _UnorderedAccessView; }
	ID3D11Texture2D*			GetStaging()
	{ return _Staging; }

	template<class T>
	T* Map()
	{
		D3D11_MAPPED_SUBRESOURCE MappedResource; 
		T* p = nullptr;
		if(SUCCEEDED(_D3DContext->Map( _Staging, 0, D3D11_MAP_READ, 0, &MappedResource )))
			p = (T*)MappedResource.pData;

		return p;
	}

private:

	void Release();
	void Unmap();
	void CopyToStaging();

	ComputeTexture(const ComputeBuffer& cb) {}
	
	ID3D11Texture2D*			_Resource;
	ID3D11ShaderResourceView*	_ResourceView;
	ID3D11UnorderedAccessView*	_UnorderedAccessView;
	ID3D11Texture2D*			_Staging;

	ID3D11DeviceContext*        _D3DContext;

	friend class ComputeWrap;
};

