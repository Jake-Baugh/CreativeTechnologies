#include "stdafx.h"
#include "Camera.h"

Camera::Camera()
{

	m_position = XMFLOAT3(0.0f, 0.0f, 0.0f);
	m_right    = XMFLOAT3(1.0f, 0.0f, 0.0f);
	m_up       = XMFLOAT3(0.0f, 1.0f, 0.0f);
	m_forward     = XMFLOAT3(0.0f, 0.0f, 1.0f);

	XMStoreFloat4x4(&m_view, XMMatrixIdentity());
	XMStoreFloat4x4(&m_projection, XMMatrixIdentity());

	m_speed			= 20.0f;
	m_deltaSpeed	= 0.0f;
}

Camera::~Camera()
{
}

void Camera::Initialize(float fieldOfView, float aspectRatio, float nearPlane, float farPlane)
{
	XMStoreFloat4x4(&m_projection, XMMatrixPerspectiveFovLH(fieldOfView, aspectRatio, nearPlane, farPlane));
}

void Camera::SetPitch(float p_angle)
{
	XMMATRIX R = XMMatrixRotationAxis(XMLoadFloat3(&m_right),	p_angle);

	XMStoreFloat3(&m_up,	XMVector3TransformNormal(XMLoadFloat3(&m_up),	R));
	XMStoreFloat3(&m_forward,	XMVector3TransformNormal(XMLoadFloat3(&m_forward), R));
}

void Camera::SetYaw(float p_angle)
{
	XMMATRIX R = XMMatrixRotationY(p_angle);

	XMStoreFloat3(&m_right,	XMVector3TransformNormal(XMLoadFloat3(&m_right),	R));
	XMStoreFloat3(&m_up,	XMVector3TransformNormal(XMLoadFloat3(&m_up),		R));
	XMStoreFloat3(&m_forward,	XMVector3TransformNormal(XMLoadFloat3(&m_forward),		R));
}

void Camera::Update( float dt )
{
	m_deltaSpeed = m_speed * dt;

	RebuildView();
}

void Camera::RebuildView()
{
	// Load Float3s into SIMD-friendly XMVECTORs
	XMVECTOR l_look		= XMLoadFloat3(&m_forward);
	XMVECTOR l_up		= XMLoadFloat3(&m_up);
	XMVECTOR l_right	= XMLoadFloat3(&m_right);
	XMVECTOR l_position = XMLoadFloat3(&m_position);


	// Keep camera's axes orthogonal to each other and of unit length.
	l_look	= XMVector3Normalize(l_look);
	l_up	= XMVector3Cross(l_look, l_right);
	l_up	= XMVector3Normalize(l_up);
	l_right	= XMVector3Cross(l_up, l_look);
	l_right = XMVector3Normalize(l_right);

	// Store the changed vectors back to Float3s
	XMStoreFloat3(&m_forward,	l_look);
	XMStoreFloat3(&m_up,	l_up);
	XMStoreFloat3(&m_right, l_right);

	// Fill in the GetViewMatrix matrix entries.
	float x = -XMVectorGetX(XMVector3Dot(l_position, l_right));
	float y = -XMVectorGetX(XMVector3Dot(l_position, l_up));
	float z = -XMVectorGetX(XMVector3Dot(l_position, l_look));

	m_view(0,0) = m_right.x; 
	m_view(1,0) = m_right.y; 
	m_view(2,0) = m_right.z; 
	m_view(3,0) = x;   

	m_view(0,1) = m_up.x;
	m_view(1,1) = m_up.y;
	m_view(2,1) = m_up.z;
	m_view(3,1) = y;  

	m_view(0,2) = m_forward.x; 
	m_view(1,2) = m_forward.y; 
	m_view(2,2) = m_forward.z; 
	m_view(3,2) = z;   

	m_view(0,3) = 0.0f;
	m_view(1,3) = 0.0f;
	m_view(2,3) = 0.0f;
	m_view(3,3) = 1.0f;
}

void Camera::Move(CAMERA_MOVEMENT_TYPE cameraMovement)
{
	switch(cameraMovement)
	{
	case MOVE_UP:
		m_position.y += m_deltaSpeed;
		break;

	case MOVE_DOWN:
		m_position.y -= m_deltaSpeed;
		break;

	case MOVE_FORWARD:
		XMStoreFloat3(&m_position, XMLoadFloat3(&m_position) + (m_deltaSpeed * XMLoadFloat3(&m_forward)));
		break;

	case MOVE_BACKWARD:
		XMStoreFloat3(&m_position, XMLoadFloat3(&m_position) - (m_deltaSpeed * XMLoadFloat3(&m_forward)));
		break;

	case STRAFE_LEFT:
		XMStoreFloat3(&m_position, XMLoadFloat3(&m_position) - (m_deltaSpeed * XMLoadFloat3(&m_right)));
		break;

	case STRAFE_RIGHT:
		XMStoreFloat3(&m_position, XMLoadFloat3(&m_position) + (m_deltaSpeed * XMLoadFloat3(&m_right)));
		break;

	default:
		m_position = XMFLOAT3(0.0f, 0.0f, 0.0f);
		break;
	}
}
