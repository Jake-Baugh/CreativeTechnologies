#ifndef MODELLOADER_
#define MODELLOADER_

#include "ComputeWrap.h"
#include <DirectXTex.h>
#include <fstream>
#include <sstream>

#include <string>
#include <vector>

using namespace DirectX;
using namespace std;

class ObjLoader
{

public:
	
	ObjLoader(ComputeWrap* p_computeWrap, ID3D11Device* p_device);
	Model*	AddStaticModel(string p_modelName, string p_OBJFileName);
	~ObjLoader();

private:

	HRESULT		CreateBuffers();
	void		CalculateBoundingBox(XMFLOAT4 p_vector3);
	void		LoadMaterialFromMTL(string p_materialPath, string p_materialFileName);
	void		LoadModelFromOBJFile(string p_modelName, string p_OBJFileName);
	int			CalculateIndex(Vertex* p_vertex);
	ID3D11ShaderResourceView*		CreateTexture(string p_textureFileName);

private:

	ID3D11Device*		m_device;
	ComputeWrap*		m_computeWrap;

	vector<Vertex>	m_vertices;

	ID3D11Buffer*		m_vertexBuffer;

	string				m_OBJFileName;

	vector<XMFLOAT4>	m_positions;
	vector<XMFLOAT4>	m_texCoords;
	vector<XMFLOAT4>	m_normals;

	Material*			m_material;

	XMFLOAT4			m_topCorner;
	XMFLOAT4			m_bottomCorner;
};
#endif