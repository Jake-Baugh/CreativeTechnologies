#ifndef STDAFX_H
#define STDAFX_H

#include <windows.h>
#include <D3D11.h>
#include <d3dCompiler.h>
#include <d3dcommon.h>
#include <DirectXMath.h>
#include <DDSTextureLoader.h>
#include <WICTextureLoader.h>

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <fstream>

using namespace DirectX;
using namespace std;

#define SAFE_RELEASE(x)			{ if (x) { (x)->Release();	(x) = nullptr; } }
#define SAFE_DELETE(x)			{ if (x) { delete (x);		(x) = nullptr; } }
#define SAFE_DELETE_ARRAY(x)	{ if (x) { delete[](x);		(x) = nullptr; } }
#define PI (3.14159265358979323846f)

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")

//32byte
struct sphereData
{
	sphereData(XMFLOAT3 pos, float rad, XMFLOAT4 color)
	{
		spherePos		= pos;
		sphereRadius	= rad;
		sphereColor		= color;
	}
	XMFLOAT3	spherePos;
	float		sphereRadius;	
	XMFLOAT4	sphereColor;
};

//144byte
struct matrixData
{
	matrixData(){}
	matrixData(XMFLOAT4X4 pviewMat, XMFLOAT4X4 pprojMat, XMFLOAT4 pcamPos)
	{
		viewMat = pviewMat;
		projMat = pprojMat;
		camPos	= pcamPos;
	}
	XMFLOAT4X4	viewMat;
	XMFLOAT4X4	projMat;
	XMFLOAT4	camPos;
};

//64byte
struct triData
{
	triData(XMFLOAT4 pp1, XMFLOAT4 pp2, XMFLOAT4 pp3, XMFLOAT4 pcolor)
	{
		p1		= pp1;
		p2		= pp2;
		p3		= pp3;
		color	= pcolor;
	}
	XMFLOAT4 p1, p2, p3, color;
};

//64byte
struct lightStruct
{
	lightStruct(){}
	lightStruct(XMFLOAT4 ppos, XMFLOAT4 pambient, XMFLOAT4 pdiffuse, XMFLOAT4 pspecular, XMFLOAT4 patt)
	{
		pos			= ppos;
		ambient		= pambient;
		diffuse		= pdiffuse;
		specular	= pspecular;
		att			= patt;
	}

	XMFLOAT4 pos, ambient, diffuse, specular, att;
};

struct Vertex
{
	XMFLOAT4 pos;
	XMFLOAT4 normal;
	XMFLOAT4 texC;
	XMFLOAT4 diff;
	XMFLOAT4 spec;
};

struct Material
{
	XMFLOAT4 m_ambient;
	XMFLOAT4 m_diffuse;
	XMFLOAT4 m_specular;
	int			m_shininess;
	float		m_alpha;
	ID3D11ShaderResourceView* m_textureResource;
	~Material()
	{
		m_textureResource->Release();
	}
};

struct Model
{
	XMFLOAT4			m_topBoundingCorner;
	XMFLOAT4			m_bottomBoundingCorner;
	ID3D11Buffer*		m_vertexBuffer;
	string				m_bufferName;
	UINT				m_offset;
	UINT				m_stride;
	int					m_size;
	Material*			m_material;

	~Model()
	{
		delete m_vertexBuffer;
		delete m_material;
	}
};

struct AABB 
{
	AABB(XMFLOAT4 minBounds, XMFLOAT4 maxBounds)
	{
		bounds[0] = minBounds;
		bounds[1] = maxBounds;
	}

	XMFLOAT4 bounds[2];
};

struct Ray
{
	//Ray direction
	XMFLOAT4 dir;	
	//Ray origin
	XMFLOAT4 origin;
};

struct HitData
{
	XMFLOAT4	hitPosition;
	//ray hit == true, ray miss == false
	bool		hitBool;
	//Hit distance
	float 		hitDist;
	//Hit UV
	XMFLOAT2		hitUV;
	//Hit triangle ID
	int 		hitTriangleID;
};

struct Variables
{
	int windowWidth;
	int windowHeight;
	int numberOfLights;
	int numberOfVertices;
};

#endif