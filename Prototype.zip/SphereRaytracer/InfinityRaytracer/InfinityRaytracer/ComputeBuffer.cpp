#include "stdafx.h"
#include "ComputeBuffer.h"

ComputeBuffer::ComputeBuffer()
{
	_Resource = nullptr;
	_ResourceView = nullptr;
	_UnorderedAccessView = nullptr;
	_Staging = nullptr;	
}

ComputeBuffer::~ComputeBuffer()
{ 
	Release(); 
}

void ComputeBuffer::Release()
{
	SAFE_RELEASE(_Resource);
	SAFE_RELEASE(_ResourceView);
	SAFE_RELEASE(_UnorderedAccessView);
	SAFE_RELEASE(_Staging);
}

void ComputeBuffer::Unmap()
{
	_D3DContext->Unmap(_Staging, 0);
}

void ComputeBuffer::CopyToStaging()
{
	_D3DContext->CopyResource( _Staging, _Resource);
}

