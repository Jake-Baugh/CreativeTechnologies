#include "stdafx.h"
#include "direct3D.h"
#include "Application.h"
#include "Timer.h"
#include <iostream>
#include <fstream>
#include <vector>

#pragma warning(disable: 4099) 

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow)
{

	Direct3D* l_direct3D = new Direct3D();

	l_direct3D->initWindow(hInstance, pCmdLine, nCmdShow);
	if(l_direct3D->initDirectX(1024, 1024));

	Timer* l_timer = new Timer(l_direct3D->getDevice(), l_direct3D->getDeviceContext());

	Application* l_directionectCompute = new Application();
	l_directionectCompute->Initialize(l_direct3D, l_timer);


	__int64 cntsPerSec = 0;
	QueryPerformanceFrequency((LARGE_INTEGER*)&cntsPerSec);
	float secsPerCnt = 1.0f / (float)cntsPerSec;

	__int64 prevTimeStamp = 0;
	QueryPerformanceCounter((LARGE_INTEGER*)&prevTimeStamp);

	int caseID = 0;

	// Main message loop
	MSG msg = {0};

	//Run main loop only if not test
	while(WM_QUIT != msg.message)
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else
		{
			__int64 currTimeStamp = 0;
			QueryPerformanceCounter((LARGE_INTEGER*)&currTimeStamp);
			float dt = (currTimeStamp - prevTimeStamp) * secsPerCnt;

			l_directionectCompute->Update(dt);
			l_directionectCompute->Render();

			prevTimeStamp = currTimeStamp;
		}
	}

	system("pause");
	return (int) msg.wParam;
}