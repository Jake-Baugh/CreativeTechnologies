#include "stdafx.h"
#include "ObjLoader.h"

ObjLoader::ObjLoader(ComputeWrap* p_computeWrap, ID3D11Device* p_device)
{
	m_device	= p_device;
	m_computeWrap = p_computeWrap;
	
	m_vertices.clear();

	m_positions.clear();
	m_positions.shrink_to_fit();
	m_texCoords.clear();
	m_texCoords.shrink_to_fit();
	m_normals.clear();
	m_normals.shrink_to_fit();

	m_topCorner = XMFLOAT4((float)INT_MAX, (float)INT_MAX, (float)INT_MAX, 0);
	m_bottomCorner = XMFLOAT4(0,0,0,0);
}

ObjLoader::~ObjLoader()
{

}

Model* ObjLoader::AddStaticModel( string p_modelName, string p_OBJFileName )
{
	LoadModelFromOBJFile(p_modelName, p_OBJFileName);

	CreateBuffers();

	Model* tmpModel = new Model();

	tmpModel->m_bufferName = p_modelName;
	tmpModel->m_vertexBuffer = m_vertexBuffer;
	tmpModel->m_offset = 0;
	tmpModel->m_stride = sizeof(Vertex);
	tmpModel->m_size = m_vertices.size();
	tmpModel->m_material = m_material;
	tmpModel->m_bottomBoundingCorner = m_bottomCorner;
	tmpModel->m_topBoundingCorner = m_topCorner;

	return tmpModel;
}

HRESULT ObjLoader::CreateBuffers()
{
	//Create Buffer
	int vertexCount = static_cast<int>(m_vertices.size());
	m_vertexBuffer = m_computeWrap->CreateConstantBuffer(sizeof(Vertex) * vertexCount,  &m_vertices.front());
	return S_OK;
}

void ObjLoader::CalculateBoundingBox(XMFLOAT4 p_vector3)
{
	if(p_vector3.x < 3 && p_vector3.x > -3 && p_vector3.y < 2 && p_vector3.y > -2 && p_vector3.z < 3 && p_vector3.z > -3)
	{
		if(m_topCorner.x == (float)INT_MAX && m_topCorner.y == (float)INT_MAX && m_topCorner.z == (float)INT_MAX)
		{
			m_topCorner = p_vector3;
			m_bottomCorner = p_vector3;
		}
		if(p_vector3.x < m_bottomCorner.x) 
			m_bottomCorner.x = p_vector3.x;
		if(p_vector3.y < m_bottomCorner.y)
			m_bottomCorner.y = p_vector3.y;
		if(p_vector3.z < m_bottomCorner.z)
			m_bottomCorner.z = p_vector3.z;
		if(p_vector3.x > m_topCorner.x)
			m_topCorner.x = p_vector3.x;
		if(p_vector3.y > m_topCorner.y)
			m_topCorner.y = p_vector3.y;
		if(p_vector3.z > m_topCorner.z)
			m_topCorner.z = p_vector3.z;
	}
}


ID3D11ShaderResourceView* ObjLoader::CreateTexture( string p_textureFileName )
{
	std::wstring wsTmp(p_textureFileName.begin(), p_textureFileName.end());

	ID3D11ShaderResourceView* resourceView = nullptr;


	CreateDDSTextureFromFile( m_device, wsTmp.c_str(), nullptr, &resourceView );
	

	return resourceView;
}

int ObjLoader::CalculateIndex( Vertex* p_vertex )
{
	int indexReturn = m_vertices.size();
	m_vertices.push_back(*p_vertex);
	return indexReturn;
}

void ObjLoader::LoadMaterialFromMTL(string p_materialPath, string p_materialFileName )
{
	m_material = new Material();

	fstream objFile(p_materialPath + "\\" + p_materialFileName);

	if(objFile)
	{
		string line;
		string prefix;

		while(objFile.eof() == false)
		{
			prefix = "NULL"; //leave nothing from the previous iteration
			stringstream lineStream;

			getline(objFile, line);
			lineStream << line;
			lineStream >> prefix;

			if(prefix == "map_Kd")
			{
				string materialTextureName;
				lineStream >> materialTextureName;
				m_material->m_textureResource = CreateTexture(p_materialPath + "\\" + materialTextureName);
			}
			else if(prefix == "Ns")
			{
				int nShininess;
				lineStream >> nShininess;
				m_material->m_shininess = nShininess;
			}
			else if(prefix == "d" || prefix == "Tr" )
			{
				lineStream >> m_material->m_alpha;
			}
			else if(prefix == "Ks")
			{
				float r, g, b;
				lineStream >> r >> g >> b;
				m_material->m_diffuse = XMFLOAT4( r, g, b, 0 );
			}
			else if(prefix == "Kd")
			{
				float r, g, b;
				lineStream >> r >> g >> b;
				m_material->m_specular = XMFLOAT4( r, g, b, 0 );
			}	
			else if(prefix == "Ka")
			{
				float r, g, b;
				lineStream >> r >> g >> b;
				m_material->m_ambient = XMFLOAT4( r, g, b, 0 );
			}
		}
	}
}

void ObjLoader::LoadModelFromOBJFile(string p_modelName, string p_OBJFileName )
{
	fstream objFile(p_OBJFileName + "\\" + p_modelName );

	if(objFile)
	{

		string strMaterialFilename;
		string line;
		string prefix;

		while(objFile.eof() == false)
		{
			prefix = "NULL"; //leave nothing from the previous iteration
			stringstream lineStream;

			getline(objFile, line);
			lineStream << line;
			lineStream >> prefix;

			if(prefix == "mtllib")
			{
				lineStream >> strMaterialFilename;
				LoadMaterialFromMTL(p_OBJFileName, strMaterialFilename);
			}
			else if(prefix == "v")
			{
				XMFLOAT4 pos;
				pos.w = 0;
				lineStream >> pos.x >> pos.y >> pos.z;
				m_positions.push_back(pos);
				CalculateBoundingBox(pos);
			}
			else if(prefix == "vt")
			{
				XMFLOAT4 uv;
				uv.y = 0;
				uv.w = 0;
				lineStream >> uv.x >> uv.y;
				uv.y = 1 - uv.y; 
				m_texCoords.push_back(uv);
			}
			else if (prefix == "vn")
			{
				XMFLOAT4 normal;
				normal.w = 0;
				lineStream >> normal.x >> normal.y >> normal.z;
				m_normals.push_back(normal);
			}
			else if(prefix == "f")
			{
				Vertex tempVertex;
				char tmp;

				int indexPos = 0;
				int texPos = 0;
				int normPos = 0;

				for(int i=0; i<3; i++)
				{

					lineStream >> indexPos >> tmp >> texPos >>  tmp >> normPos;

					ZeroMemory(&tempVertex, sizeof(Vertex));
					
					tempVertex.pos = m_positions[ indexPos - 1];
					tempVertex.texC = m_texCoords[ texPos - 1 ]; 
					tempVertex.normal = m_normals[ normPos - 1 ]; 
					tempVertex.diff = m_material->m_diffuse;
					tempVertex.spec = m_material->m_specular;

					m_vertices.push_back(tempVertex);

				}
			}
		}
	}

}

