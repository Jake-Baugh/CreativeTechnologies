#ifndef DIRECT3D_H
#define DIRECT3D_H

#include "stdafx.h"

using namespace DirectX;

class Direct3D
{
public:
	Direct3D();
	~Direct3D();
	
	HRESULT initWindow(HINSTANCE p_hInstance, PWSTR p_pCmdLine, int p_nCmdShow);
	HRESULT initDirectX(int p_width, int p_height);

	IDXGISwapChain*				getSwapChain();
	ID3D11Device*				getDevice();
	ID3D11DeviceContext*		getDeviceContext();
	ID3D11UnorderedAccessView*	getUAV();
	HWND						getMainWindowHandle();
	int							getWindowWidth();
	int							getWindowHeight();
	XMFLOAT2					getMousePos();
	LRESULT msgProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );	
private:
	HWND m_hwnd;

	int m_width, m_height;

	XMFLOAT2 m_mousePos;

	IDXGISwapChain*				m_swapChain;
	ID3D11Device*				m_device;
	ID3D11DeviceContext*		m_deviceContext;
	ID3D11UnorderedAccessView*  m_backBufferUAV;  
};
#endif
