#pragma once

#include "stdafx.h"
#include <tchar.h>

class ComputeShader
{
public:

	~ComputeShader();

private:
	
	explicit ComputeShader();

	bool Init(TCHAR* shaderFile, TCHAR* blobFileAppendix, char* pFunctionName, D3D10_SHADER_MACRO* pDefines,
		ID3D11Device* d3dDevice, ID3D11DeviceContext*d3dContext);

	ID3D11Device*               mD3DDevice;
	ID3D11DeviceContext*        mD3DDeviceContext;

	ID3D11ComputeShader*		mShader;

public:

	void Set();
	void Unset();
	
	friend class ComputeWrap;
};
