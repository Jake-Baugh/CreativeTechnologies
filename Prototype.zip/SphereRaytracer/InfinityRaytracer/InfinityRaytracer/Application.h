#ifndef DIRECTCOMPUTE_H
#define DIRECTCOMPUTE_H
#include "Direct3D.h"
#include "Timer.h"
#include "ComputeBuffer.h"
#include "ComputeShader.h"
#include "ComputeWrap.h"
#include "ComputeTexture.h"
#include "Camera.h"
#include "ObjLoader.h"

using namespace DirectX;

class Application
{
public:
	Application();
	~Application();

	HRESULT Initialize(Direct3D* direct3D, Timer* timer);
	HRESULT Render();
	HRESULT Update(float dt);

	//Setters
	void setNumberOfBounces(int value);
	void setNumberOfVertices(int value);
	void setNumberOfLights(int value);
	void setResolution(int width, int height);
	void setThreadGroupSize(int x, int y);

	//Getters
	double getPrimaryStageTime();
	double getIntersectionStageTime();
	double getColorStageTime();

private:
	void UpdateInput();
	void updateKB();
	void CreateBuffer();
	void UpdateBuffer(ID3D11Buffer* buffer, void* data, unsigned size);
	void PrintTitle();

private:
	Direct3D*		m_direct3D;
	Timer*		m_timer;
	ComputeWrap*	m_computeSys;

	ComputeShader*	m_primaryRayCS;
	ComputeShader*	m_intersectionCS;
	ComputeShader*	m_colorCS;

	ComputeBuffer*	m_rayBuffer;
	ComputeBuffer*	m_hitDataBuffer;
	ComputeBuffer*	m_colorBuffer;

	Camera*			m_camera;
	ObjLoader*	m_modelLoader;

	ID3D11Buffer*	m_camerabuffer;
	ID3D11Buffer*	m_lightBuffer;
	ID3D11Buffer*	m_AABBBuffer;
	ID3D11Buffer*	m_loopBuffer;
	ID3D11Buffer*	m_varBuffer;

	Model*			m_model;

	matrixData		m_mdata;

	XMFLOAT2		m_oldMousePos;

	lightStruct		m_pointLights[10];

	Variables		m_variables;

	float m_ftimer;

	int m_bounceCount;

	int m_threadsPerGroupX;
	int m_threadsPerGroupY;

	int m_threadGroupX;
	int m_threadGroupY;

	bool m_testFlag;

	double m_rayCreationTime, m_intersectionTime, m_colorTime;
	
};
#endif
