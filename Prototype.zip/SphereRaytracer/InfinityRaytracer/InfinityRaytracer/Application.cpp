#include "stdafx.h"
#include "Application.h"

Application::Application()
{
}


Application::~Application()
{
}

HRESULT Application::Initialize( Direct3D* direct3D, Timer* timer)
{
	m_direct3D		= direct3D;
	m_timer			= timer;
	m_oldMousePos	= m_direct3D->getMousePos();
	m_ftimer		= 0;
	m_bounceCount	= 1;

	m_camera = new Camera();
	m_camera->Initialize(PI / 4, (float)m_direct3D->getWindowWidth()/(float)m_direct3D->getWindowHeight(), 5.0f, 1000.0f);


	for(int i = 0; i < 10; i++)
		m_pointLights[i] = lightStruct(
		XMFLOAT4(0.0f, 0.0f, 0.0f, 0.0f),
		XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f),
		XMFLOAT4(0.5f, 0.5f, 0.5f, 1.0f),
		XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f),
		XMFLOAT4(0.0f, 0.5f, 0.0f, 10.0f));

	m_computeSys = new ComputeWrap(m_direct3D->getDevice(), m_direct3D->getDeviceContext());
	m_modelLoader = new ObjLoader(m_computeSys, m_direct3D->getDevice());

	CreateBuffer();
	
	m_variables.numberOfLights = 1;
	m_variables.numberOfVertices = 800;
	m_variables.windowWidth = m_direct3D->getWindowWidth();
	m_variables.windowHeight = m_direct3D->getWindowWidth();

	setThreadGroupSize(16,16);

	ShowCursor(false);

	UpdateInput();

	return S_OK;
}

HRESULT Application::Render()
{
	m_rayCreationTime = m_intersectionTime = m_colorTime = 0.0f;

	ID3D11UnorderedAccessView* clearUAV[]			= { 0,0,0,0,0,0,0 };
	ID3D11UnorderedAccessView* ray[]				= { m_rayBuffer->GetUnorderedAccessView(), m_direct3D->getUAV() };
	ID3D11UnorderedAccessView* intersection[]		= {	m_rayBuffer->GetUnorderedAccessView(), m_hitDataBuffer->GetUnorderedAccessView()};
	ID3D11UnorderedAccessView* uav[]				= { m_direct3D->getUAV(), m_colorBuffer->GetUnorderedAccessView(), m_hitDataBuffer->GetUnorderedAccessView() };

	m_direct3D->getDeviceContext()->CSSetConstantBuffers(0, 1, &m_camerabuffer);

	m_direct3D->getDeviceContext()->CSSetConstantBuffers(1, 1, &m_lightBuffer);

	m_direct3D->getDeviceContext()->CSSetConstantBuffers(2, 1, &m_model->m_vertexBuffer);

	m_direct3D->getDeviceContext()->CSSetConstantBuffers(3, 1, &m_AABBBuffer);

	m_direct3D->getDeviceContext()->CSSetConstantBuffers(4, 1, &m_loopBuffer);

	m_direct3D->getDeviceContext()->CSSetConstantBuffers(5, 1, &m_varBuffer); 

	m_direct3D->getDeviceContext()->CSSetShaderResources(0, 1, &m_model->m_material->m_textureResource);

	//////////////////////////////////////////////////////////////////////////
	//Primary ray stage
	//////////////////////////////////////////////////////////////////////////

	m_direct3D->getDeviceContext()->CSSetUnorderedAccessViews(0, 1, ray, NULL);

	m_primaryRayCS->Set();
	m_timer->Start();
	m_direct3D->getDeviceContext()->Dispatch( m_threadGroupX, m_threadGroupY, 1 );
	m_timer->Stop();
	m_primaryRayCS->Unset();

	m_rayCreationTime = m_timer->GetTime();

	m_direct3D->getDeviceContext()->CSSetUnorderedAccessViews(0, 1, clearUAV, NULL);

 	for(int i = 0; i < m_bounceCount; ++i)
	{
		UpdateBuffer(m_loopBuffer, &i, sizeof(int));

		//////////////////////////////////////////////////////////////////////////
		//Intersection Stage
		//////////////////////////////////////////////////////////////////////////
		m_direct3D->getDeviceContext()->CSSetUnorderedAccessViews(0, 2, intersection, NULL);

		m_intersectionCS->Set();
		m_timer->Start();
		m_direct3D->getDeviceContext()->Dispatch( m_threadGroupX, m_threadGroupY, 1 );
		m_timer->Stop();
		m_intersectionCS->Unset();

		m_intersectionTime += m_timer->GetTime();

		m_direct3D->getDeviceContext()->CSSetUnorderedAccessViews(0, 1, clearUAV, NULL);

		//////////////////////////////////////////////////////////////////////////
		//Color Stage
		//////////////////////////////////////////////////////////////////////////
		m_direct3D->getDeviceContext()->CSSetUnorderedAccessViews(0, 3, uav, NULL);

		m_colorCS->Set();
		m_timer->Start();
		m_direct3D->getDeviceContext()->Dispatch( m_threadGroupX, m_threadGroupY, 1 );
		m_timer->Stop();
		m_colorCS->Unset();

		m_colorTime += m_timer->GetTime();
		m_direct3D->getDeviceContext()->CSSetUnorderedAccessViews(0, 1, clearUAV, NULL);
	}
	
	if(FAILED(m_direct3D->getSwapChain()->Present( 0, 0 )))
		return E_FAIL;

	PrintTitle();

	return S_OK;
}

HRESULT Application::Update( float dt )
{
	m_ftimer += dt;

	UpdateInput();


	m_camera->Update(dt);

	//Set new inverse matrices
	XMStoreFloat4x4(&m_mdata.viewMat, XMMatrixInverse(0, XMLoadFloat4x4(&m_camera->GetViewMatrix())));
	XMStoreFloat4x4(&m_mdata.projMat, XMMatrixInverse(0, XMLoadFloat4x4(&m_camera->GetProjMatrix())));
	m_mdata.camPos	= XMFLOAT4(m_camera->GetPosition().x,m_camera->GetPosition().y, m_camera->GetPosition().z, 0.0f);

	for(int i = 0; i < 10; i++)
		m_pointLights[i].pos = XMFLOAT4(sin(3.14f + m_ftimer*(i+1)*0.2f)*2.99f, 0.0f, cos(3.14f + m_ftimer*(i+1)*0.2f)*2.99f, 0.0f);
	m_pointLights[1].pos = XMFLOAT4(sin(m_ftimer*0.2f)*3.0f, 0.0f, cos(3.14f + m_ftimer*0.2f)*3.0f, 0.0f);

	//Update camera buffer
	UpdateBuffer(m_camerabuffer, &m_mdata, sizeof(matrixData));

	//Update light buffer
	UpdateBuffer(m_lightBuffer, &m_pointLights[0], (sizeof(lightStruct) * 10));

	return S_OK;
}

void Application::UpdateInput()
{
	float mx = m_direct3D->getMousePos().x;
	float my = m_direct3D->getMousePos().y;

	POINT p;
	p.x = (LONG)m_direct3D->getWindowWidth()*0.5;
	p.y = (LONG)m_direct3D->getWindowHeight()*0.5;

	m_camera->SetPitch((my - p.y) * 0.00087266f);
	m_camera->SetYaw((mx - p.x) * 0.00087266f);

	ClientToScreen(m_direct3D->getMainWindowHandle(), &p);
	SetCursorPos(p.x, p.y);	
	
	if(GetAsyncKeyState('W') & 0x8000)
		m_camera->Move(MOVE_FORWARD);
	if(GetAsyncKeyState('S') & 0x8000)
		m_camera->Move(MOVE_BACKWARD);
	if(GetAsyncKeyState('A') & 0x8000)
		m_camera->Move(STRAFE_LEFT);
	if(GetAsyncKeyState('D') & 0x8000)
		m_camera->Move(STRAFE_RIGHT);
	if(GetAsyncKeyState('X') & 0x8000)
		m_camera->Move(MOVE_DOWN);
	if(GetAsyncKeyState('Z') & 0x8000)
		m_camera->Move(MOVE_UP);

	for(int i = 1; i < 10; ++i)
	{
		if(GetAsyncKeyState(i + 48) & 0x8000)
		{
			if(GetAsyncKeyState('B') & 0x8000)
				setNumberOfBounces(i); 
			if(GetAsyncKeyState('L') & 0x8000)
				setNumberOfLights(i);
			if(GetAsyncKeyState('V') & 0x8000)
				setNumberOfVertices((int)(465 / i));

			UpdateBuffer(m_varBuffer, &m_variables, sizeof(Variables));
		}
	}
}

void Application::CreateBuffer()
{
	//Create dynamic buffer for camera matrices
	m_camerabuffer		= m_computeSys->CreateDynamicBuffer(sizeof(matrixData), 0); 
	//Create light buffer
	m_lightBuffer	= m_computeSys->CreateDynamicBuffer(sizeof(lightStruct) * 10, &m_pointLights[0]);

	//
	m_model	= m_modelLoader->AddStaticModel("tree.obj", "model");

	//Constant buffer for model AABB
	m_AABBBuffer	= m_computeSys->CreateConstantBuffer(sizeof(AABB), &AABB(m_model->m_bottomBoundingCorner, m_model->m_topBoundingCorner));

	//Structured buffers
	m_rayBuffer		= m_computeSys->CreateBuffer(STRUCTURED_BUFFER, sizeof(Ray),m_direct3D->getWindowHeight() * m_direct3D->getWindowWidth(), true, true, NULL,true, "raybuffer");
	m_hitDataBuffer = m_computeSys->CreateBuffer(STRUCTURED_BUFFER, sizeof(HitData),m_direct3D->getWindowHeight() * m_direct3D->getWindowWidth(), true, true, NULL,true, "sgsdgs");
	m_colorBuffer	= m_computeSys->CreateBuffer(STRUCTURED_BUFFER, sizeof(XMFLOAT4),m_direct3D->getWindowHeight() * m_direct3D->getWindowWidth(), true, true, NULL,true, "raysdgsdgsewbuffer");

	m_loopBuffer	= m_computeSys->CreateDynamicBuffer(sizeof(int), 0); 
	m_varBuffer		= m_computeSys->CreateDynamicBuffer(sizeof(Variables), &m_variables); 
}

void Application::UpdateBuffer( ID3D11Buffer* buffer, void* data, unsigned size )
{
	void* verticesPtr;

	D3D11_MAPPED_SUBRESOURCE l_mapped;
	m_direct3D->getDeviceContext()->Map(buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &l_mapped);

	// Get a pointer to the data in the vertex buffer.
	verticesPtr = (void*)l_mapped.pData;

	// Copy the data into the vertex buffer.
	memcpy(verticesPtr, data, size);

	// Unlock the vertex buffer.
	m_direct3D->getDeviceContext()->Unmap(buffer, 0);
}

void Application::setNumberOfBounces( int value )
{
	m_bounceCount = value;
}

void Application::setNumberOfVertices( int value )
{
	m_variables.numberOfVertices = value;
	UpdateBuffer(m_varBuffer, &m_variables, sizeof(Variables));
}

void Application::setNumberOfLights( int value )
{
	m_variables.numberOfLights = value;
	UpdateBuffer(m_varBuffer, &m_variables, sizeof(Variables));
}

void Application::setResolution( int width, int height )
{
	m_variables.windowWidth = width;
	m_variables.windowHeight = height;

	m_threadGroupX = m_variables.windowWidth / m_threadsPerGroupX;
	m_threadGroupY = m_variables.windowHeight / m_threadsPerGroupY;

	UpdateBuffer(m_varBuffer, &m_variables, sizeof(Variables));
}

double Application::getPrimaryStageTime()
{
	return m_rayCreationTime;
}

double Application::getIntersectionStageTime()
{
	return m_intersectionTime;
}

double Application::getColorStageTime()
{
	return m_colorTime;
}

void Application::PrintTitle()
{
	char title[256];
	sprintf_s(
		title,
		sizeof(title),
		"Infinity Raytracer: Ray: %f ms, Intersection: %f ms, Color: %f ms",
		m_rayCreationTime, m_intersectionTime, m_colorTime
		);
	SetWindowTextA(m_direct3D->getMainWindowHandle(), title);
}

void Application::setThreadGroupSize( int x, int y )
{
	//Create new shaders and compile with new Defines.fx
	m_primaryRayCS		= m_computeSys->CreateComputeShader(_T("../Shaders/Ray.hlsl"), NULL, "main", NULL);
	m_intersectionCS	= m_computeSys->CreateComputeShader(_T("../Shaders/Intersection.hlsl"), NULL, "main", NULL);
	m_colorCS			= m_computeSys->CreateComputeShader(_T("../Shaders/Colour.hlsl"), NULL, "main", NULL);

	//Set other data
	m_threadsPerGroupX = x;
	m_threadsPerGroupY = y;

	m_threadGroupX = m_variables.windowWidth / m_threadsPerGroupX;
	m_threadGroupY = m_variables.windowHeight / m_threadsPerGroupY;

	UpdateBuffer(m_varBuffer, &m_variables, sizeof(Variables));
}
