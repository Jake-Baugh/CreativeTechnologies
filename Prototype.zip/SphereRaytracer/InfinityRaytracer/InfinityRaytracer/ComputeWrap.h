#pragma once

#include "ComputeShader.h"
#include "ComputeBuffer.h"
#include "ComputeTexture.h"

class ComputeWrap
{
	ID3D11Device*               mD3DDevice;
	ID3D11DeviceContext*        mD3DDeviceContext;

public:

	ComputeWrap(ID3D11Device* d3dDevice, ID3D11DeviceContext* d3dContext);
	~ComputeWrap();

	ComputeShader* CreateComputeShader(TCHAR* shaderFile, TCHAR* blobFileAppendix, char* pFunctionName, D3D10_SHADER_MACRO* pDefines);

	ID3D11Buffer* CreateConstantBuffer(UINT uSize, VOID* pInitData, char* debugName = nullptr);
	ID3D11Buffer* CreateDynamicBuffer(UINT uSize, VOID* pInitData, char* debugName = nullptr);

	ComputeBuffer* CreateBuffer(COMPUTE_BUFFER_TYPE uType, UINT uElementSize,
		UINT uCount, bool bSRV, bool bUAV, VOID* pInitData, bool bCreateStaging = false, char* debugName = nullptr);

	ComputeTexture* CreateTexture(DXGI_FORMAT dxFormat,	UINT uWidth,
		UINT uHeight, UINT uRowPitch, VOID* pInitData, bool bCreateStaging = false, char* debugName = nullptr);

	ComputeTexture* CreateTexture(TCHAR* textureFilename, char* debugName = nullptr);

private:
	ID3D11Buffer* CreateStructuredBuffer(UINT uElementSize, UINT uCount, bool bSRV, bool bUAV, VOID* pInitData);
	ID3D11Buffer* CreateRawBuffer(UINT uSize, VOID* pInitData);
	ID3D11ShaderResourceView* CreateBufferSRV(ID3D11Buffer* pBuffer);
	ID3D11UnorderedAccessView* CreateBufferUAV(ID3D11Buffer* pBuffer);
	ID3D11Buffer* CreateStagingBuffer(UINT uSize);

	//texture functions
	ID3D11Texture2D* CreateTextureResource(DXGI_FORMAT dxFormat,
		UINT uWidth, UINT uHeight, UINT uRowPitch, VOID* pInitData);
	//ID3D11Buffer* CreateRawBuffer(UINT uSize, VOID* pInitData);
	ID3D11ShaderResourceView* CreateTextureSRV(ID3D11Texture2D* pTexture);
	ID3D11UnorderedAccessView* CreateTextureUAV(ID3D11Texture2D* pTexture);
	ID3D11Texture2D* CreateStagingTexture(ID3D11Texture2D* pTexture);

	void SetDebugName(ID3D11DeviceChild* object, char* debugName);
};


