#include "stdafx.h"
#include "ComputeTexture.h"

ComputeTexture::ComputeTexture()
{
	_Resource = NULL;
	_ResourceView = NULL;
	_UnorderedAccessView = NULL;
	_Staging = NULL;
}

ComputeTexture::~ComputeTexture()
{
	Release();
}

void ComputeTexture::Release()
{
	SAFE_RELEASE(_Resource);
	SAFE_RELEASE(_ResourceView);
	SAFE_RELEASE(_UnorderedAccessView);
	SAFE_RELEASE(_Staging);
}

void ComputeTexture::Unmap()
{
	_D3DContext->Unmap(_Staging, 0);
}

void ComputeTexture::CopyToStaging()
{
	_D3DContext->CopyResource( _Staging, _Resource);
}