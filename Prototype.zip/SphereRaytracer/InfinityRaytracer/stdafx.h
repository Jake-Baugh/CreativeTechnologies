#ifndef STDAFX_H
#define STDAFX_H

#include <windows.h>
#include <D3D11.h>
#include <d3dCompiler.h>
#include <d3dcommon.h>
#include <DirectXMath.h>

#include <string>
#include <vector>
#include <map>
#include <fstream>

#define SAFE_RELEASE(x)			{ if (x) { (x)->Release();	(x) = nullptr; } }
#define SAFE_DELETE(x)			{ if (x) { delete (x);		(x) = nullptr; } }
#define SAFE_DELETE_ARRAY(x)	{ if (x) { delete[](x);		(x) = nullptr; } }
#define PI (3.14159265358979323846f)

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")

#endif