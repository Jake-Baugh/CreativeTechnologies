#ifndef direct3D_H
#define direct3D_H

#include "stdafx.h"

using namespace DirectX;

class Direct3D
{
public:
	Direct3D();
	~Direct3D();
	
	HRESULT InitializeWindow(HINSTANCE p_hInstance, PWSTR p_pCmdLine, int p_nCmdShow);
	HRESULT InitializeDirectX();

	IDXGISwapChain*				GetSwapChain() { return m_swapChain; }
	ID3D11Device*				GetDevice() { return m_device; }
	ID3D11DeviceContext*		GetDeviceContext() { return m_deviceContext; }
	ID3D11UnorderedAccessView*	GetUnorderedAccessView() { return m_backBufferUAV; }
	HWND						GetMainWindowHandle() { return m_hwnd; }
	int							GetWindowWidth() { return m_width; }
	int							GetWindowHeight() { return m_height; }
	XMFLOAT2					GetMousePos() { return m_mousePos; }

	LRESULT msgProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );	
private:
	HWND m_hwnd;

	int m_width, m_height;

	XMFLOAT2 m_mousePos;

	IDXGISwapChain*				m_swapChain;
	ID3D11Device*				m_device;
	ID3D11DeviceContext*		m_deviceContext;
	ID3D11UnorderedAccessView*  m_backBufferUAV;  
};
#endif
