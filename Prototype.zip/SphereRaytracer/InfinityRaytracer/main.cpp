#include "stdafx.h"
#include "direct3D.h"
#include "Application.h"
#include "Timer.h"

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow)
{
	Direct3D* l_direct3D = new Direct3D();

	l_direct3D->InitializeWindow(hInstance, pCmdLine, nCmdShow);
	l_direct3D->InitializeDirectX();
	
	Timer* l_timer = new Timer(l_direct3D->GetDevice(), l_direct3D->GetDeviceContext());

	Application* l_directionectCompute = new Application();
	l_directionectCompute->Initialize(l_direct3D, l_timer);


	__int64 cntsPerSec = 0;
	QueryPerformanceFrequency((LARGE_INTEGER*)&cntsPerSec);
	float secsPerCnt = 1.0f / (float)cntsPerSec;

	__int64 prevTimeStamp = 0;
	QueryPerformanceCounter((LARGE_INTEGER*)&prevTimeStamp);

	// Main message loop
	MSG msg = {0};
	while(WM_QUIT != msg.message)
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE) )
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}
		else
		{
			__int64 currTimeStamp = 0;
			QueryPerformanceCounter((LARGE_INTEGER*)&currTimeStamp);
			float dt = (currTimeStamp - prevTimeStamp) * secsPerCnt;

			l_directionectCompute->Update(dt);
			l_directionectCompute->Render();

			prevTimeStamp = currTimeStamp;
		}
	}

	return (int) msg.wParam;
}