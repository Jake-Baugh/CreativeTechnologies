#ifndef DIRECTCOMPUTE_H
#define DIRECTCOMPUTE_H
#include "Direct3D.h"
#include "Timer.h"
#include "Compute.h"
#include "Camera.h"
using namespace DirectX;

struct Sphere
{
	XMFLOAT3	spherePos;
	float		sphereRadius;	
	XMFLOAT4	sphereColor;
};

struct Matrix
{
	Matrix(){}
	Matrix(XMFLOAT4X4 pviewMat, XMFLOAT4X4 pprojMat, XMFLOAT4 pcamPos)
	{
		viewMat = pviewMat;
		projMat = pprojMat;
		cameraPosition	= pcamPos;
	}
	XMFLOAT4X4	viewMat;
	XMFLOAT4X4	projMat;
	XMFLOAT4	cameraPosition;
};

struct Tri
{
	Tri(XMFLOAT4 pp1, XMFLOAT4 pp2, XMFLOAT4 pp3, XMFLOAT4 pcolor)
	{
		p1		= pp1;
		p2		= pp2;
		p3		= pp3;
		color	= pcolor;
	}
	XMFLOAT4 p1, p2, p3, color;
};

struct PointLight
{
	XMFLOAT4 position;
	XMFLOAT4 ambient;
	XMFLOAT4 diffuse; 
	XMFLOAT4 specular;
	XMFLOAT4 attenuation;

};

struct Window
{
	int width;
	int height;
};

class Application
{
public:

	Application();
	~Application();

	HRESULT Initialize(Direct3D* direct3D, Timer* timer);
	HRESULT Render();
	HRESULT Update(float dt);

private:

	void UpdateInput();
	void CreateBuffer();
	void UpdateBuffer(ID3D11Buffer* buffer, void* data, unsigned size);
	void SetResolution( int width, int height );
private:

	Direct3D*		m_direct3D;
	Timer*			m_timer;
	ComputeWrap*	m_compute;
	ComputeShader*	m_computeShader;
	Camera*			m_camera;

	ComputeBuffer*	m_sphereBuffer;
	ID3D11Buffer*   m_windowBuffer;
	ID3D11Buffer*	m_cameraBuffer;
	ID3D11Buffer*	m_tribuffer;
	ID3D11Buffer*	m_lightBuffer;

	std::vector<Sphere>	m_sphere;
	Matrix			m_cameraMatrix;
	PointLight		m_pointLight;
	Window          m_window;

	XMFLOAT2		m_oldMousePos;

	float			m_ftimer;

	int m_threadsPerGroupX;
	int m_threadsPerGroupY;

	int m_threadGroupX;
	int m_threadGroupY;

};
#endif
